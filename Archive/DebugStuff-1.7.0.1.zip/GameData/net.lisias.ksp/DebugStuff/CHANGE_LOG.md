# Debug Stuff /L Unleashed :: Change Log

* 2022-1010: 1.7.0.1 (LisiasT) for KSP >= 1.4.0
	+ Making the thing working again downto 1.4.0
	+ Using KSPe facilities
* 2020-0629: 1.7.0.0 (Sarbian) for KSP >= 1.8.0
	+ Add missing method
* 2019-1022: 1.6.1 (Sarbian) for KSP 1.8.0
	+ More GUI info by DMagic
	+ Fix #4
* 2019-1018: 1.6.0 (Sarbian) for KSP 1.8.0
	+ Show whether a GameObject is active
	+ Adds an A:True/False indicator to each game object which says whether
	+ it's active (note - this is whether the game object itself is active,
	+ not whether it's active in the hierarchy which depends on the parents)
	+ Add toggle to show active/all GOs
	+ If the switch is set to active and a GameObject is not active in the
	+ hierarchy, none of its component indicators will be rendered.  Note that
	+ everything is still shown in the hiearchy list.
	+ Add support for WheelCollider
* 2018-0402: 1.5.1 (Sarbian) for KSP 1.4.1
	+ DebugDrawer Fix the scene transition NRE breaking stuff
* 2018-0313: 1.5 (Sarbian) for KSP 1.4.0
	+ No changelog provided
* 2016-1025: 1.4.0.0 (Sarbian) for KSP 1.3.0
	+ No changelog provided
* 2016-0417: 1.3 (Sarbian) for KSP 1.2.0
	+ Improvement to the Object mode
* 2016-0405: 1.2 (Sarbian) for KSP 1.2.0
	+ Working Object mode
	+ Improve the GL drawing performance
* 2016-0404: 1.1 (Sarbian) for KSP 1.2.0
	+ No changelog provided
* 2016-0401: 1.0.0.0 (Sarbian) for KSP 1.2.0
	+ Err - Stupid me ?
